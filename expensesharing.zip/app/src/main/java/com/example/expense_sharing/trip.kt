package com.example.expense_sharing

data class trip(val tripid:String?=null,val name:String?=null)
