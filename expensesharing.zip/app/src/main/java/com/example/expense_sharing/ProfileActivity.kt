package com.example.expense_sharing

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        val intent = intent
        val name = intent.getStringExtra("name")
        val email = intent.getStringExtra("email")
        val uri = intent.getStringExtra("photo_url")
        val textviewn = findViewById<TextView>(R.id.acct_name)
        val textviewe = findViewById<TextView>(R.id.acct_email)
        textviewn.text = name
        textviewe.text = email
        fun onBackPressed() {
            super.onBackPressed()
            val intent = Intent(this@ProfileActivity, HomeActivity::class.java)
            startActivity(intent)
        }
    }
}