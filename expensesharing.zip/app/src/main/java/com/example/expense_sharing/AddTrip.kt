package com.example.expense_sharing

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddTrip : AppCompatActivity() {
    lateinit var database : DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_trip)
        val btn =findViewById<Button>(R.id.add_trip)
        btn.setOnClickListener{
            add_trip()
    }
    }
    private fun add_trip() {
        val tripn = findViewById<EditText>(R.id.trip_name)
        val tripname = tripn.text.toString().trim()
        if(tripname.isNotEmpty()){
            database = FirebaseDatabase.getInstance().getReference("trip")
            val trip_id = database.push().key
            val trip = trip(trip_id,tripname)
            if (trip_id != null) {
                database.child(trip_id).setValue(trip).addOnCompleteListener{
                    Toast.makeText(applicationContext,"trip added",Toast.LENGTH_LONG).show()
                    tripn.text.clear()
                    val intent = Intent(this,HomeActivity::class.java)
                    startActivity(intent)

                }
            }



        }
    }

}