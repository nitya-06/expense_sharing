package com.example.expense_sharing

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText

class MemberActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_member)
        findViewById<Button>(R.id.submit).setOnClickListener{
            val m1 = findViewById<EditText>(R.id.m1name).text.toString().trim()
            val m2 = findViewById<EditText>(R.id.m2name).text.toString().trim()
            val m3 = findViewById<EditText>(R.id.m3name).text.toString().trim()
            val m4 = findViewById<EditText>(R.id.m4name).text.toString().trim()
            val m5 = findViewById<EditText>(R.id.m5name).text.toString().trim()
            val m1paid = findViewById<EditText>(R.id.m1paid).text.toString().trim().toDouble()
            val m2paid = findViewById<EditText>(R.id.m2paid).text.toString().trim().toDouble()
            val m3paid = findViewById<EditText>(R.id.m3paid).text.toString().trim().toDouble()
            val m4paid = findViewById<EditText>(R.id.m4paid).text.toString().trim().toDouble()
            val m5paid = findViewById<EditText>(R.id.m5paid).text.toString().trim().toDouble()
            var intent = Intent(this,SplitActivity::class.java)
//            Log.i("info",m1)
//            Log.i("info",m2)
//            Log.i("info",m3)
//            Log.i("info",m4)
//            Log.i("info",m5)
            intent.putExtra("m1name",m1)
            intent.putExtra("m2name",m2)
            intent.putExtra("m3name",m3)
            intent.putExtra("m4name",m4)
            intent.putExtra("m5name",m5)
            intent.putExtra("m1paid",m1paid)
            intent.putExtra("m2paid",m2paid)
            intent.putExtra("m3paid",m3paid)
            intent.putExtra("m4paid",m4paid)
            intent.putExtra("m5paid",m5paid)
            startActivity(intent)
        }
    }


}